function inserirMateria(){

	var contador = document.getElementsByClassName('resultadoEscolhas')[0].childElementCount; /*document.getElementByClassName('resultadoEscolhas') vai
		trazer um vetor de de elementos que contem a classe resultadoEscolhas, depois o [0] representa o primeiro elemente desse vetor. O childElementCount 
		retorna a quantidade de elementos dentro da div para usar como id único*/
	var materia = document.getElementById('materias').value;
	var date = document.getElementById('pickDate').value;
	var time =document.getElementById('pickTime').value;
	
	var container = '<div id="de'+contador+'"class="divEscolhas" data-send="'+materia+';'+date+';'+time+'"><span>'+materia+' | '+date+' '+time+
	'</span><button class="botaoRemoveHorario" onclick="removeMateria('+"'"+'de'+contador+"'"+')">Remover</button></div>';
	
	document.getElementsByClassName('resultadoEscolhas')[0].innerHTML += container;
	
}

function removeMateria(idEsc){
	document.getElementById(idEsc).remove();
}

var enviou = false;
window.onload = function (){
	var formulario = document.getElementById('sendResult');
	formulario.reset();
	formulario.onsubmit = function(e){
		if(enviou == true)
		return false;
		
		enviou = true;
		formulario.method ="POST";
		formulario.action = "?";
		
		var envio = "";
		var divsSend = document.getElementsByClassName('divEscolhas');
		for(var i = 0; i < divsSend.length;i++){
			var prefixo = i > 0? "&":"";
			envio += prefixo + divsSend[i].getAttribute('data-send');
		}
		var ele = document.createElement('INPUT');
		ele.type = 'hidden';
		ele.name = 'selectedList';
		ele.value = envio;
		formulario.appendChild(ele);
		
		return true;
	};
};